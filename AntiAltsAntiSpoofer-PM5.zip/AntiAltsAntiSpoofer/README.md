# AntiAlts + AntiSpoofer — PocketMine-MP 5

Plugin PHP con archivos separados por responsabilidad y SQLite persistente.

## Estructura
- `src/Lunaria/AntiAlts/Main.php`: inicialización y eventos.
- `player/PlayerDataCollector.php`: captura identificadores.
- `storage/AltStorage.php`: almacenamiento e índices SQLite.
- `analysis/RiskAnalyzer.php`: cálculo de riesgo.
- `alert/AlertManager.php`: alertas al staff.
- `command/AltsCommand.php`: comando `/alts`.
- `resources/config.yml`: configuración.

## Instalación
1. Coloca la carpeta `AntiAltsAntiSpoofer` en `plugins/` o compílala como `.phar`.
2. Inicia PocketMine-MP 5 una vez para generar `plugin_data/AntiAltsAntiSpoofer/`.
3. Configura `config.yml` y reinicia.
4. Permisos: `antialts.command` y `antialts.alerts` (por defecto OP).

## Identificadores y límites reales
PMMP 5 ofrece IP de la sesión, XUID (si hay autenticación Xbox), UUID y datos de login Bedrock como DeviceId, DeviceOS, DeviceModel y ClientRandomId dentro de los datos adicionales cuando el protocolo/servidor los expone. La disponibilidad concreta depende de la versión y del proveedor de login. El plugin no puede leer un HWID físico real ni garantizar que DeviceId/ClientRandomId no puedan falsificarse. Device OS/modelo son señales débiles y están desactivadas por defecto.

## Anti-spoofer
La primera versión conserva identificadores históricos para detectar cambios y coincidencias, calcula puntuación, y marca si alguna cuenta relacionada aparece en la lista de baneos; no aplica baneos automáticos para evitar falsos positivos. Una IP compartida no debe considerarse prueba suficiente de multicuentas.

## Nota técnica
La base usa SQLite con WAL e índices. Para servidores muy grandes, conviene mover lecturas/escrituras a tareas asíncronas y aplicar retención/limpieza de registros.
